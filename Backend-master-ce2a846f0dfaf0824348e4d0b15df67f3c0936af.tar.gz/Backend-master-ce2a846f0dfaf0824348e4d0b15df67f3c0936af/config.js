module.exports = {
  'secret': 'cmkmCK8RfZJe*=2o+r2y=GvC^dF#R^KkmgGeLfryPvnBpAFy2dXNt4m2sHPasdf'
};
