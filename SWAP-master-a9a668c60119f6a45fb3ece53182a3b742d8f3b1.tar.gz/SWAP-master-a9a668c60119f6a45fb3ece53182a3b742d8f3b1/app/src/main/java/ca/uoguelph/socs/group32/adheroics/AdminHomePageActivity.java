package ca.uoguelph.socs.group32.adheroics;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AdminHomePageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home_page);
    }
}
