package ca.uoguelph.socs.group32.adheroics.Resources;

/**
 * Created by Justin on 2017-11-20.
 */

public class Constants {
    public static final int IS_ADMIN = 3;
    public static final int IS_SW = 2;
    public static final int IS_USER = 1;
    public static final int IS_NOT_VALID = 0;
    public static final String SERVER_IP = "https://131.104.180.104";
    public static final String PORT = ":3000";
}
